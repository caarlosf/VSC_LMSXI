## Your name and surnames

#### Carlos Ferrer Osorio
###### 1ºDAW I.E.S. San Clemente

## An achievement/ experience you’re really proud of
So far there is nothing notable that comes to mind, I am still working on my goals, but I have not completed them yet, and they still require more time and dedication


## Your personal hero
I don´t have a personal hero, i think that any person is too good or too perfect to idolize.

I only follow many persons in specific things but i never came to idolize and allways doubting and checking what they say or do and been too critical with them.


## The worst food in the world
For me __all the vegetables dishes__ are the worst. I don't like too much the vegetables.


## The three more useful/entertaining apps
Probably the most useful app for me is _YouTube_, is the perfect way to leern a lot of complex and etended things in a simple way and to discover new things.

_Instagram_ and _Telegram_ are other two apps that i like, because you can follow persons who talk about interesting things. Obviously controling the use time and having different accounts to separate the personal or entertaiment things from the things that i want to leern or persons who contribute with interesting things.

For me is to important limit the use of the second and third app, form example in my case the personal or entertaiment accounts i only can use one time in the day and not more than one hour but i try to use less than this.

1. [YouTube](https://www.youtube.com/)
1. [Instagram](https://www.instagram.com/)
1. [Telegram](https://web.telegram.org/)


## The best gift you have ever received/given
I don't have a better gift but to say somthing probably the time and the things that i do with my family and friends.
I don't like too much give or recive material gifts.


## A dream that you have to accomplish
In the entertaining way, my realistic dreams are drive a _KartCross_ and a _KZ Kart_.

>My too difficult dream is __drive an F1 car__ from the 00's and other from the 90's
or __ride in a supersonic fighter plane__.


## If you could time travel to any year in the past or future, which would you choose?
I only like go to the past but i don't have a special preference about one year, i would like go to the _III Reich Germany, the Roman Empire period, the Vikings period and the Spanish colonization of the Americas_ these are the firsts periods that i think but not only the unics that i would like to travel.


## Two hobbies
* Cars and Motorsport
* Sports (i like sports in general but my two favourite sports are)
  * Football
  * Cycling

![](https://cdn.pixabay.com/photo/2024/03/12/20/34/ai-generated-8629506_1280.jpg)

![](https://cdn.pixabay.com/photo/2013/10/02/15/00/stadium-189777_960_720.jpg)

![](https://cdn.pixabay.com/photo/2019/08/09/06/12/car-racing-4394450_960_720.jpg)
## Your English level (have you got any certification?)
My english level is not too good, i pass the _E.S.O._ level and the _1ª Bachillerato_, but **my last time studing english was 6 years ago** and i don´t remember the gratest part of the content.

I never had a very big ability to understand the speaking languaje, for example with the films or youtube videos.


## Your Computer Science background

I did the Medium FP __SMR__.

I always have facility in my enviroment to understand, learn and do things with the computers and smartphones.